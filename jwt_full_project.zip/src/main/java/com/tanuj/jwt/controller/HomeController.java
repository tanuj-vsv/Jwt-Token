
package com.tanuj.jwt.controller;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class HomeController {

  @GetMapping("/List")
  public String getMessage() {
    String username = SecurityContextHolder.getContext().getAuthentication().getName();
    return "Hey " + username + ", Welcome in Spring Boot 🚀";
  }
}
