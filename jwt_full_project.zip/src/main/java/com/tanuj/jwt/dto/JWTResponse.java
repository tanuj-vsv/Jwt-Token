
package com.tanuj.jwt.dto;

public class JWTResponse {
  private String token;
  public JWTResponse(String token){this.token=token;}
  public String getToken(){return token;}
}
