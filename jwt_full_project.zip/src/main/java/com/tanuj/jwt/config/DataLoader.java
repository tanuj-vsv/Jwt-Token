
package com.tanuj.jwt.config;

import com.tanuj.jwt.entity.User;
import com.tanuj.jwt.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {

  @Autowired private UserRepository repo;

  @Bean
  CommandLineRunner init() {
    return args -> {
      if (repo.findByUsername("tanuj").isEmpty()) {
        User u = new User();
        u.setUsername("tanuj");
        u.setPassword("1234");
        repo.save(u);
      }
    };
  }
}
