
package com.tanuj.jwt.controller;

import com.tanuj.jwt.config.JwtHelper;
import com.tanuj.jwt.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

  @Autowired private AuthenticationManager manager;
  @Autowired private JwtHelper jwtHelper;

  @PostMapping("/login")
  public ResponseEntity<?> login(@RequestBody JWTRequest request) {
    try {
      manager.authenticate(new UsernamePasswordAuthenticationToken(
          request.getUsername(), request.getPassword()));
    } catch (BadCredentialsException e) {
      return ResponseEntity.status(401).body("Username or Password Invalid");
    }
    String token = jwtHelper.generateToken(request.getUsername());
    return ResponseEntity.ok(new JWTResponse(token));
  }
}
